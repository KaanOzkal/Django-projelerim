from django.shortcuts import render
from.models import *
# Create your views here.py 

def anasayfa(request):
    urun=urunler.objects.all()
    context={
        "urunler":urun
    }
    return render(request,"index.html",context)
def detay(request,id):
    urun=urunler.objects.filter(id=id)
    context={
        "urun":urun
    }
    return render(request,"detay.html",context)