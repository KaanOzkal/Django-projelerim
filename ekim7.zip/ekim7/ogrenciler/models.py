from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Ogrenciler(models.Model):
    owner=models.ForeignKey(User,on_delete=models.CASCADE,null=True,blank=True)
    isim=models.CharField(max_length=100,verbose_name="öğrenci ad")
    soyad=models.CharField(max_length=100,verbose_name="öğrenci soyadı")
    resim=models.FileField(upload_to="ogrenciResim",verbose_name="öğrenci fotosu")
    hakkında=models.TextField(max_length=500,verbose_name="öğrenci hakkında")

    def __str__(self):
        return self.isim +" "+ self.soyad