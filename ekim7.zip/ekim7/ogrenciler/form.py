from django.forms import ModelForm
from .models import *
class OgrenciForm(ModelForm):
    class Meta:
        model=Ogrenciler
        fields=["isim","soyad","hakkında","resim"]


    def __ini__(self,*args,**kwargs):
        super(OgrenciForm,self).__init__(*args,**kwargs)
        self.fields["isim"].widget.attrs.update({"class":"form-control"})
        self.fields["soyad"].widget.attrs.update({"class":"form-control"})
        self.fields["hakkında"].widget.attrs.update({"class":"form-control"})
        self.fields["resim"].widget.attrs.update({"class":"form-control"})